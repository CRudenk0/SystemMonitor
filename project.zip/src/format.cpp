#include <string>
#include <cmath>
#include <iomanip>

#include "format.h"

using std::string;

// TODO: Complete this helper function
// INPUT: Long int measuring seconds
// OUTPUT: HH:MM:SS
// REMOVE: [[maybe_unused]] once you define the function
string Format::ElapsedTime(long seconds)
{ 
    long hours = seconds / 3600;
    long minutes = (seconds % 3600) / 60;
    long remaining_seconds = seconds % 60;

    std::ostringstream formatted_hours; 
    formatted_hours << std::setfill('0') << std::setw(2) << hours;
    std::ostringstream formatted_minutes; 
    formatted_minutes << std::setfill('0') << std::setw(2) << minutes;
    std::ostringstream formatted_seconds; 
    formatted_seconds << std::setfill('0') << std::setw(2) << remaining_seconds;

    std::string formatted_time = formatted_hours.str() + ':' + formatted_minutes.str() + ':' + formatted_seconds.str();
       
    return formatted_time; 
}