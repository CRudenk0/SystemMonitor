#ifndef PROCESSOR_H
#define PROCESSOR_H

#include <vector>
#include <map>
#include <string>


class Processor {
 public:
  //Constructor
  float Utilization();  // TODO: See src/processor.cpp
 

  // TODO: Declare any necessary private members
 private:
  long NonIdle_ = 0;
  long Idle_ = 0;
  float cpu_percentage_ = 0;
};

#endif