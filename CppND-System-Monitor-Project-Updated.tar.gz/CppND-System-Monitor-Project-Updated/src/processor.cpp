#include "processor.h"
#include "linux_parser.h"
#include <vector>
#include <string>
#include <map>


using std::vector;
using std::string;
using std::stof;


// TODO: Return the aggregate CPU utilization
float Processor::Utilization() 
{ 
    
    long PrevIdle = Idle_;
    long Idle = LinuxParser::IdleJiffies();

    long PrevNonIdle = NonIdle_;
    long NonIdle = LinuxParser::ActiveJiffies();
    
    long PrevTotal = PrevIdle  + PrevNonIdle;
    long Total = Idle + NonIdle;

    long totald = Total - PrevTotal;
    long idled = Idle - PrevIdle;

    float cpu_percentage = (float(totald) - float(idled)) / float(totald);
    
    cpu_percentage_ = cpu_percentage;

    return cpu_percentage_;
}

